package com.example.shippingdriverapplication.supports;


public class MessageEvent {
    //public NotificationData notificationData;

//    public MessageEvent(NotificationData notificationData) {
//        this.notificationData = notificationData;
//    }
}
